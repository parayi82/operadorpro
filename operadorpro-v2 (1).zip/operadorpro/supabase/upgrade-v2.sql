-- ============================================================
-- OperadorPro v2 - Script de ACTUALIZACIÓN
-- Para bases de datos que ya ejecutaron el schema.sql original.
-- Ejecutar completo en: Supabase > SQL Editor > New query
-- (Instalaciones nuevas: usar schema.sql, que ya incluye esto)
-- ============================================================

-- Plan contratado: none | esencial | protegido
alter table public.profiles
  add column if not exists plan text not null default 'none';

-- Vigencia del examen psicofísico integral (para alertas)
alter table public.profiles
  add column if not exists examen_medico_vigencia date;

-- Los usuarios con suscripción activa previa a v2 quedan como 'esencial'
update public.profiles
  set plan = 'esencial'
  where subscription_status = 'active' and plan = 'none';

-- Actualizar la política para que el usuario tampoco pueda cambiar su plan
drop policy if exists "perfil: actualizar propio" on public.profiles;
create policy "perfil: actualizar propio" on public.profiles
  for update using (auth.uid() = id)
  with check (
    auth.uid() = id
    and subscription_status = (select p.subscription_status from public.profiles p where p.id = auth.uid())
    and coalesce(stripe_customer_id,'') = coalesce((select p.stripe_customer_id from public.profiles p where p.id = auth.uid()),'')
    and plan = (select p.plan from public.profiles p where p.id = auth.uid())
  );
