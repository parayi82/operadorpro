// ============================================================
// OperadorPro - Configuración pública del cliente (v2)
// Estas llaves SÍ pueden ir en el frontend (publishable key con RLS).
// Las llaves secretas van SOLO en variables de entorno de Netlify.
// ============================================================

const CONFIG = {
  SUPABASE_URL: "https://siqkkcltkrmdexxlcuat.supabase.co",
  SUPABASE_ANON_KEY: "TU_PUBLISHABLE_KEY_AQUI",      // <-- Pega tu sb_publishable_...
  SITE_URL: "https://operadorpro.netlify.app",

  // Número de WhatsApp para asesoría legal (formato internacional SIN + ni espacios)
  // Ejemplo México: 5213312345678  (52 + 1 + 10 dígitos)
  WHATSAPP_ASESORIA: "52XXXXXXXXXXX",                // <-- Reemplazar

  PLANES: {
    esencial:  { nombre: "Esencial",  precio: "$149 MXN/mes" },
    protegido: { nombre: "Protegido", precio: "$349 MXN/mes" }
  }
};
