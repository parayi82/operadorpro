// ============================================================
// OperadorPro - Contenido de cursos
// 3 cursos MVP: Carta Porte, NOM-087, Protocolo de accidente
// Cada curso: lecciones (HTML) + examen de 10 reactivos (aprueba con 8)
// NOTA LEGAL: contenido de referencia. Verificar siempre el texto
// vigente de las NOM y reglas del SAT antes de publicar a producción.
// ============================================================

const COURSES = [
  {
    id: "carta-porte",
    title: "Carta Porte sin errores",
    badge: "CP",
    color: "#05603A",
    desc: "Domina el complemento Carta Porte del SAT: qué revisar antes de salir, qué mostrar en una verificación y cómo evitar que un error documental detenga tu viaje.",
    duracion: "≈ 50 min",
    lessons: [
      {
        id: "cp-1",
        title: "Qué es la Carta Porte y quién la emite",
        html: `
          <p>El <strong>complemento Carta Porte</strong> es un anexo al CFDI (factura electrónica) exigido por el SAT para acreditar el traslado legal de mercancías por territorio nacional, especialmente en <strong>tramos de jurisdicción federal</strong>: carreteras federales, autopistas y cruces entre estados.</p>
          <p>Puntos que todo operador debe tener claros:</p>
          <ul>
            <li><strong>Quién lo emite:</strong> el transportista (tu empresa o tú, si eres hombre-camión con tus propios permisos) cuando cobra por el flete, mediante un <em>CFDI de Ingreso</em> con complemento Carta Porte. Si el dueño de la mercancía la mueve con su propia flota, emite un <em>CFDI de Traslado</em> con el complemento.</li>
            <li><strong>Tú no lo generas, pero tú respondes en el camino.</strong> El documento lo timbra el área administrativa; el que lo presenta ante la autoridad en carretera eres tú. Un error que administración no vio se convierte en tu problema en el retén.</li>
            <li><strong>El documento ampara el viaje completo:</strong> mercancía, ruta, unidad, remolques y operador. Si algo de eso cambia (te cambian de caja, de tracto o de ruta), la Carta Porte debe reflejarlo.</li>
          </ul>
          <p class="tip">Regla de oro: <strong>si lo que traes cargado, la unidad que manejas o la ruta que sigues no coinciden con el papel, el viaje está en riesgo.</strong> Detecta la diferencia antes que el verificador.</p>
        `
      },
      {
        id: "cp-2",
        title: "Los datos que TÚ debes revisar antes de arrancar",
        html: `
          <p>Antes de mover la unidad, dedica 5 minutos a este checklist sobre la representación de la Carta Porte que te entreguen:</p>
          <ol>
            <li><strong>Tus datos como operador:</strong> nombre completo, RFC (o CURP en su caso) y <strong>número de licencia federal vigente</strong>. Una licencia vencida o mal capturada invalida tu parte del documento.</li>
            <li><strong>La unidad:</strong> placas del tracto y de cada remolque, configuración vehicular (ej. T3S2, T3S2R4), número de permiso SICT. Verifica placa por placa contra la unidad física.</li>
            <li><strong>La mercancía:</strong> descripción y cantidades a grandes rasgos. No necesitas auditar la factura, pero si el papel dice "abarrotes" y traes acero, detén todo y llama a tu empresa.</li>
            <li><strong>Origen y destino:</strong> que coincidan con las instrucciones reales del viaje, incluyendo paradas intermedias si las hay.</li>
            <li><strong>Material peligroso:</strong> si aplica, debe indicarlo con su clave, y tú debes contar con la categoría de licencia correspondiente (E) y la unidad con sus autorizaciones.</li>
            <li><strong>El folio fiscal y el IdCCP:</strong> que el documento tenga folio fiscal (UUID) y el identificador del complemento. Sin timbrar no ampara nada: es solo un papel.</li>
          </ol>
          <p class="tip">Si la empresa te dice "luego te lo mandamos, arranca": <strong>no arranques en tramo federal sin el documento</strong>. La multa y la retención de la unidad ocurren donde tú estás, no donde está la oficina.</p>
        `
      },
      {
        id: "cp-3",
        title: "En la verificación: qué mostrar y cómo",
        html: `
          <p>En un punto de verificación (SAT, Guardia Nacional, SICT) te pueden pedir que acredites el traslado. Reglas prácticas:</p>
          <ul>
            <li><strong>Formato válido:</strong> puedes mostrar la representación <strong>impresa o digital</strong> (PDF en tu teléfono o tableta). Lo importante es que sea legible y contenga el folio fiscal y el código QR.</li>
            <li><strong>Ten un plan B sin señal:</strong> guarda el PDF descargado en el teléfono (no dependas de WhatsApp con señal) y de preferencia lleva una impresión. En muchos tramos federales no hay datos móviles.</li>
            <li><strong>Documentos compañeros:</strong> licencia federal vigente, tarjeta de circulación del tracto y remolques, póliza de seguro, y en su caso permisos de material peligroso o carga sobredimensionada. La Carta Porte no sustituye a los demás documentos.</li>
            <li><strong>Actitud en el punto:</strong> baja la ventanilla, entrega lo que te pidan, no discutas el criterio en el momento. Si el verificador señala una inconsistencia, pide que te la muestre en el documento, anótala y comunícala de inmediato a tu empresa. Tu trabajo es documentar, no litigar en la carretera.</li>
            <li><strong>Nunca entregues tu teléfono desbloqueado.</strong> Muestra tú el documento en pantalla; el aparato no sale de tu mano.</li>
          </ul>
          <p class="tip">Anota siempre: hora, kilómetro o caseta, corporación y número de unidad oficial. Ese registro vale oro si después hay una sanción que impugnar.</p>
        `
      },
      {
        id: "cp-4",
        title: "Errores comunes, sanciones y cómo protegerte",
        html: `
          <p>Los errores que más viajes detienen:</p>
          <ul>
            <li>Placas del remolque distintas a las capturadas (cambiaron la caja al último minuto).</li>
            <li>Operador distinto al registrado (relevo de operador no reportado).</li>
            <li>Licencia federal vencida o de categoría incorrecta para la configuración o la carga.</li>
            <li>Documento sin timbrar, ilegible o "en camino".</li>
            <li>Mercancía que no corresponde con la descripción.</li>
          </ul>
          <p><strong>Qué arriesga la empresa:</strong> multas fiscales que pueden llegar a decenas de miles de pesos por documento, y en traslados de comercio exterior la mercancía sin Carta Porte válida puede presumirse contrabando, con consecuencias mucho más graves.</p>
          <p><strong>Qué arriesgas tú:</strong> horas o días detenido con la unidad, señalamientos de la empresa, y en el peor escenario verte involucrado en una carpeta por mercancía irregular que tú no cargaste ni revisaste.</p>
          <p><strong>Cómo te proteges:</strong></p>
          <ol>
            <li>Haz el checklist de la lección 2 en <em>cada</em> viaje y consérvalo (una foto del documento y de tu unidad antes de salir es evidencia con fecha).</li>
            <li>Reporta por escrito (mensaje a tu empresa) cualquier inconsistencia que detectes; que quede constancia de que avisaste.</li>
            <li>Nunca aceptes transportar carga que no esté documentada "porque es un favor". El que la trae a bordo eres tú.</li>
          </ol>
          <p class="tip">Un operador que sabe leer una Carta Porte y detecta errores antes de salir le ahorra a la empresa multas y días de unidad parada. Eso es exactamente lo que este certificado acredita ante un reclutador.</p>
        `
      }
    ],
    quiz: [
      { q: "¿En qué tramos es exigible acreditar el traslado con el complemento Carta Porte?", options: ["Solo dentro de las ciudades", "En tramos de jurisdicción federal (carreteras federales y cruces entre estados)", "Solo en cruces fronterizos", "Únicamente en autopistas de cuota"], correct: 1 },
      { q: "Si el transportista cobra por el flete, el complemento Carta Porte se incorpora a un:", options: ["CFDI de Traslado", "CFDI de Nómina", "CFDI de Ingreso", "Recibo simple en papel"], correct: 2 },
      { q: "Te cambian el remolque al último minuto y las placas ya no coinciden con la Carta Porte. Lo correcto es:", options: ["Salir y explicar en el retén si preguntan", "No arrancar hasta que corrijan y retimbren el documento", "Tapar la placa del remolque", "Llevar las dos cajas anotadas a mano"], correct: 1 },
      { q: "¿En qué formato puedes mostrar la Carta Porte en una verificación?", options: ["Solo impresa con sello original", "Solo digital en la app del SAT", "Impresa o digital, siempre que sea legible y tenga folio fiscal y QR", "No es necesario mostrarla si llevas factura"], correct: 2 },
      { q: "¿Cuál de estos datos del OPERADOR debe estar correcto en la Carta Porte?", options: ["Su número de seguro social", "Su número de licencia federal vigente", "Su domicilio particular completo", "Su antigüedad en la empresa"], correct: 1 },
      { q: "Un documento de Carta Porte sin timbrar (sin folio fiscal/UUID):", options: ["Vale igual si trae el logo de la empresa", "Sirve como comprobante provisional por 72 horas", "No ampara el traslado: es solo un papel", "Solo sirve para carga ligera"], correct: 2 },
      { q: "En el punto de verificación, la mejor práctica con tu teléfono es:", options: ["Entregarlo desbloqueado para agilizar", "Mostrar tú el PDF en pantalla sin soltar el aparato", "Decir que no traes documentos digitales", "Mandar el PDF por WhatsApp al oficial"], correct: 1 },
      { q: "Detectas que el papel dice 'abarrotes' pero la carga es acero. ¿Qué haces?", options: ["Arrancas, porque la carga no es tu responsabilidad", "Detienes el viaje y avisas de inmediato a la empresa, por escrito", "Corriges el documento a mano", "Solo lo comentas al llegar al destino"], correct: 1 },
      { q: "¿Por qué conviene reportar por escrito las inconsistencias que detectes antes de salir?", options: ["Para que te paguen horas extra", "Porque queda constancia con fecha de que tú avisaste", "Porque lo exige la Guardia Nacional", "No conviene: es mejor no dejar rastro"], correct: 1 },
      { q: "En comercio exterior, mercancía trasladada sin Carta Porte válida puede:", options: ["Generar solo una llamada de atención", "Presumirse contrabando, con consecuencias graves", "Regularizarse pagando la caseta", "No tiene consecuencia si el chofer no es el dueño"], correct: 1 }
    ]
  },

  {
    id: "nom-087",
    title: "NOM-087: tiempos de conducción y descanso",
    badge: "087",
    color: "#B45309",
    desc: "Las reglas de horas de servicio del autotransporte federal: cuánto puedes conducir, cuándo debes parar, cómo se registra y qué pasa si un accidente ocurre con fatiga de por medio.",
    duracion: "≈ 45 min",
    lessons: [
      {
        id: "n87-1",
        title: "Por qué existe la norma y a quién aplica",
        html: `
          <p>La <strong>NOM-087-SCT-2-2017</strong> regula los <strong>tiempos de conducción y pausas</strong> de los conductores del autotransporte federal. Nació de una realidad que todo operador conoce: la <strong>fatiga</strong> es de las principales causas de accidentes graves en carretera, comparable en efectos a conducir con alcohol.</p>
          <ul>
            <li><strong>Aplica</strong> a conductores de vehículos de autotransporte federal de carga, pasaje y turismo en vías generales de comunicación (carreteras federales).</li>
            <li><strong>Obliga a dos partes:</strong> al operador, a respetar los tiempos; y al permisionario (la empresa), a programar los viajes de forma que puedan cumplirse. Una empresa que te asigna una ruta imposible sin violar la norma está incumpliendo ella también.</li>
            <li><strong>Importa aunque nadie te revise:</strong> más allá de la sanción, el registro de tus tiempos es tu <em>defensa</em> si hay un accidente: demuestra que tú operabas dentro de norma.</li>
          </ul>
          <p class="tip">Piensa en la norma como tu escudo laboral y penal, no como un estorbo: un operador dentro de tiempos tiene una posición legal completamente distinta tras un percance.</p>
        `
      },
      {
        id: "n87-2",
        title: "Las reglas: horas al volante y pausas",
        html: `
          <p>Las reglas centrales de tiempos que establece la norma para el autotransporte federal:</p>
          <ul>
            <li><strong>Conducción continua:</strong> después de un máximo de <strong>5 horas y media</strong> de conducción continua, debes hacer una <strong>pausa mínima de 30 minutos</strong>. La pausa puede fraccionarse dentro del periodo, pero el descanso debe ser efectivo (no es pausa seguir maniobrando o cargando).</li>
            <li><strong>Tope de conducción acumulada:</strong> el tiempo efectivo de conducción no debe exceder <strong>14 horas</strong>; alcanzado ese tope, corresponde un <strong>descanso mínimo de 8 horas consecutivas</strong> antes de volver al volante.</li>
            <li><strong>Doble tripulación:</strong> en servicios con dos operadores, los tiempos se controlan por operador: el que descansa en el camarote acumula descanso, el que conduce acumula conducción. El relevo no "resetea" tus horas, las pausa.</li>
          </ul>
          <p><strong>Ojo con la trampa mental común:</strong> el tope es de <em>conducción</em>, pero tu jornada laboral (LFT) incluye también cargas, esperas y maniobras. Puedes estar dentro de la NOM y aun así fuera de la jornada legal — ambos límites cuentan y ambos son exigibles.</p>
          <p class="tip">Verifica siempre la versión vigente de la norma y las políticas internas de tu empresa: algunas flotas serias operan con límites internos más estrictos que la NOM, y esos también te obligan por contrato.</p>
        `
      },
      {
        id: "n87-3",
        title: "La bitácora de horas de servicio",
        html: `
          <p>El cumplimiento se acredita con la <strong>bitácora de horas de servicio</strong>, que registra tus periodos de conducción, pausas y descansos.</p>
          <ul>
            <li><strong>Quién la lleva:</strong> tú la llenas, la empresa la conserva. Puede ser en formato físico o mediante sistemas electrónicos/GPS que registren los tiempos de la unidad.</li>
            <li><strong>Quién la puede revisar:</strong> la autoridad (SICT/Guardia Nacional en operativos) y los inspectores en verificación. También es documento clave en cualquier peritaje tras un accidente.</li>
            <li><strong>Cómo llenarla bien:</strong> registra la realidad, con horas de inicio y fin de cada periodo. Una bitácora "maquillada" que no coincide con el GPS de la unidad o con los tickets de casetas es peor que ninguna: acredita falsedad.</li>
            <li><strong>Guarda tu propio respaldo:</strong> una foto de tu bitácora al final de cada jornada crea tu archivo personal. Si un día la empresa y tú difieren sobre lo que pasó, tendrás tu evidencia.</li>
          </ul>
          <p class="tip">GPS de la unidad, tickets de caseta, cámaras de peaje y tu bitácora deben contar la misma historia. Cuando no coinciden, la autoridad cree en los datos electrónicos, no en el papel.</p>
        `
      },
      {
        id: "n87-4",
        title: "Fatiga: detectarla, manejarla y sus consecuencias legales",
        html: `
          <p><strong>Señales de fatiga que ningún operador profesional ignora:</strong> parpadeo pesado y microsueños (despertar sin recordar los últimos segundos), invadir rayas sin darte cuenta, no recordar los últimos kilómetros, bostezos constantes, irritabilidad, "ver" cosas en la orilla.</p>
          <p><strong>Qué sí funciona contra la fatiga:</strong> detenerte y dormir 20–30 minutos (la única medida realmente efectiva), pausas programadas antes de sentirte mal, hidratarte y comer ligero. <strong>Qué no funciona:</strong> subir el volumen, abrir la ventana, o encadenar bebidas energéticas — retrasan el sueño unos minutos y provocan un desplome peor.</p>
          <p><strong>Consecuencias legales de un accidente con fatiga demostrable:</strong></p>
          <ul>
            <li>Si tu bitácora o el GPS muestran que excediste los tiempos, la fatiga puede tomarse como elemento de <strong>culpa o negligencia</strong> en la carpeta de investigación, agravando tu situación penal y la responsabilidad civil.</li>
            <li>Si la <strong>empresa te programó</strong> fuera de norma, esa evidencia también reparte la responsabilidad hacia el permisionario — otra razón para conservar mensajes donde te asignan rutas y horarios.</li>
            <li>Negarte a conducir excediendo los tiempos de norma <strong>no es insubordinación</strong>: es cumplimiento de una obligación legal. Documenta la negativa por escrito y con respeto.</li>
          </ul>
          <p class="tip">Frase para tu empresa cuando te presionen: "Dentro de norma llego mañana temprano; fuera de norma, a lo mejor no llego". Un profesional administra sus tiempos como administra su diésel.</p>
        `
      }
    ],
    quiz: [
      { q: "¿Cuál es una de las principales causas de accidentes graves que la NOM-087 busca combatir?", options: ["El exceso de dimensiones", "La fatiga del conductor", "La falta de seguro", "La sobrecarga de los ejes"], correct: 1 },
      { q: "Tras un máximo de 5 horas y media de conducción continua, corresponde:", options: ["Cambiar de operador obligatoriamente", "Una pausa mínima de 30 minutos", "Terminar la jornada", "Reportarse a la SICT"], correct: 1 },
      { q: "Alcanzado el tope de conducción efectiva acumulada (14 horas), debes tomar:", options: ["Una pausa de 30 minutos", "Un descanso mínimo de 8 horas consecutivas", "Un café y continuar", "Descanso solo si hay pensión disponible"], correct: 1 },
      { q: "La NOM-087 obliga:", options: ["Solo al operador", "Solo a la empresa permisionaria", "Al operador y a la empresa que programa los viajes", "Solo a las flotas de más de 50 unidades"], correct: 2 },
      { q: "¿Cuál es la ÚNICA medida realmente efectiva contra la fatiga al volante?", options: ["Bebidas energéticas encadenadas", "Música a alto volumen", "Detenerse y dormir 20–30 minutos", "Ventanilla abierta"], correct: 2 },
      { q: "Una bitácora 'maquillada' que no coincide con el GPS de la unidad:", options: ["No tiene consecuencias", "Es mejor que nada", "Es peor que ninguna: acredita falsedad", "Solo importa en accidentes con heridos"], correct: 2 },
      { q: "En doble tripulación, el relevo de operador:", options: ["Resetea tus horas de conducción", "Pausa tu conteo mientras descansas; no lo borra", "Duplica el tope permitido", "Elimina la obligación de bitácora"], correct: 1 },
      { q: "Tu empresa te asigna una ruta imposible sin exceder los tiempos de la norma. Negarte:", options: ["Es insubordinación y causal de despido", "Es cumplimiento de una obligación legal; documéntalo por escrito", "Solo es válido si eres sindicalizado", "Es válido pero pierdes el viaje sin defensa"], correct: 1 },
      { q: "Tras un accidente, ¿qué papel juega tu bitácora si operabas dentro de tiempos?", options: ["Ninguno, solo cuenta el peritaje de la unidad", "Es tu defensa: demuestra que operabas en norma", "Solo sirve para el seguro", "Se entrega únicamente a la empresa"], correct: 1 },
      { q: "El tope de conducción de la NOM y la jornada laboral de la LFT:", options: ["Son lo mismo con distinto nombre", "Solo aplica el que convenga a la empresa", "Son límites distintos y ambos son exigibles", "La NOM sustituye a la LFT en carretera"], correct: 2 }
    ]
  },

  {
    id: "protocolo-accidente",
    title: "Protocolo de accidente en carretera",
    badge: "SOS",
    color: "#B91C1C",
    desc: "Los primeros 60 minutos deciden tu situación legal. Qué hacer, qué decir, qué no firmar y cuáles son tus derechos si interviene el Ministerio Público.",
    duracion: "≈ 45 min",
    lessons: [
      {
        id: "pa-1",
        title: "Los primeros 10 minutos: seguridad y aviso",
        html: `
          <p>Pasó lo que no querías. El orden de prioridades en los primeros minutos es siempre el mismo:</p>
          <ol>
            <li><strong>Tu integridad primero.</strong> Evalúa si puedes moverte, si hay fuego, derrame o riesgo de volcadura secundaria. Un operador lesionado no puede ayudar a nadie.</li>
            <li><strong>Asegura la zona.</strong> Luces intermitentes, torreta si tienes, y coloca los <strong>triángulos o dispositivos de advertencia</strong> a distancia suficiente para que el tráfico reaccione (en carretera federal, piensa en cientos de metros, no en diez pasos; más lejos en curvas, pendientes o de noche). El segundo accidente sobre la escena es tristemente común y suele ser peor.</li>
            <li><strong>Llama al 911.</strong> Reporta: kilómetro y tramo exactos, número de vehículos, si hay lesionados y de qué gravedad, si hay derrame o material peligroso. Di tu nombre y número de contacto.</li>
            <li><strong>No muevas a los lesionados</strong> salvo riesgo inminente (fuego, explosión). Moverlos puede agravar lesiones y complicar tu situación legal. Sí puedes: hablarles, cubrirlos, contener una hemorragia con presión directa si sabes hacerlo.</li>
            <li><strong>No muevas las unidades</strong> si hay lesionados o daños mayores: la posición final es evidencia. Si es un percance menor sin lesionados y las unidades estorban con riesgo, fotografía todo desde varios ángulos ANTES de mover.</li>
          </ol>
          <p class="tip">Memoriza el orden: <strong>YO → ZONA → 911 → HERIDOS → EVIDENCIA</strong>. En pánico, el orden memorizado sustituye al criterio que se nubla.</p>
        `
      },
      {
        id: "pa-2",
        title: "Con quién hablar y qué decir (y qué no)",
        html: `
          <p>Después del 911, tus llamadas en orden:</p>
          <ol>
            <li><strong>Tu empresa</strong> (o tu aseguradora si eres hombre-camión): reporta hechos objetivos. La empresa activa a su ajustador y a su área legal.</li>
            <li><strong>La aseguradora de la unidad:</strong> el número viene en la póliza. Pide número de reporte y nombre del ajustador asignado. <strong>No negocies nada con el tercero antes de que llegue el ajustador.</strong></li>
          </ol>
          <p><strong>Frente a la autoridad (Guardia Nacional, policía) y frente al tercero:</strong></p>
          <ul>
            <li>Describe <strong>hechos, no conclusiones</strong>: "circulaba por el carril derecho a esta velocidad aproximada, el vehículo apareció desde…" — nunca "fue mi culpa", "me distraje", "iba tarde". La determinación de responsabilidad corresponde al perito, no a ti ni al oficial en la escena.</li>
            <li><strong>No firmes nada que no entiendas o que no puedas leer completo.</strong> Ni convenios con el tercero, ni "responsivas" improvisadas. Si te presionan a firmar, escribe junto a tu firma "recibo, sin aceptar contenido" — o mejor, espera al ajustador o al abogado.</li>
            <li><strong>No entregues documentos originales</strong> al tercero. Al oficial, entrega lo que legalmente te requiera y anota su nombre, corporación y número de unidad.</li>
            <li>Con el tercero mantén trato correcto y breve. Nada de discusiones, ofertas de dinero ni amenazas: todo eso reaparece después como declaración testimonial.</li>
          </ul>
          <p class="tip">La frase profesional universal: <em>"El ajustador y el área legal de mi empresa vienen en camino; con ellos se acuerda todo."</em> Te quita presión y no admite nada.</p>
        `
      },
      {
        id: "pa-3",
        title: "Evidencia: tu cámara es tu abogado en la escena",
        html: `
          <p>Mientras llegan ajustador y autoridad, documenta. Checklist de evidencia:</p>
          <ul>
            <li><strong>Panorámicas</strong> de la escena desde los 4 puntos cardinales, que se vea la posición final de todas las unidades y el entorno (curva, pendiente, señalamiento, estado del pavimento).</li>
            <li><strong>Acercamientos</strong> de daños de todas las unidades (también las del tercero), huellas de frenado, derrames, piezas desprendidas.</li>
            <li><strong>Condiciones:</strong> clima, visibilidad, iluminación. Un video de 360° con la voz narrando hora y lugar vale doble.</li>
            <li><strong>Del tercero:</strong> placas, número de serie si es visible, licencia, póliza, nombre y teléfono. Fotografía los documentos, no los transcribas.</li>
            <li><strong>Testigos:</strong> nombre y teléfono de quien haya visto algo. Dos líneas de lo que dicen. Los testigos se van en minutos y no regresan.</li>
            <li><strong>Tus documentos del viaje:</strong> ten a la mano licencia, tarjetas de circulación, póliza, Carta Porte y tu bitácora de horas (recuerda: si estabas dentro de tiempos, tu bitácora te defiende).</li>
          </ul>
          <p>Envía todo de inmediato a tu empresa/abogado por un canal que deje constancia (correo o mensaje), no lo dejes solo en la galería del teléfono.</p>
          <p class="tip">Regla del profesional: <strong>documentas como si fueras a perder el juicio</strong>. Si nunca hace falta, perfecto; si hace falta, ganaste.</p>
        `
      },
      {
        id: "pa-4",
        title: "Si interviene el Ministerio Público: tus derechos",
        html: `
          <p>Cuando hay lesionados graves o fallecidos, el asunto se vuelve penal y probablemente serás presentado ante el <strong>Ministerio Público</strong>. Aquí es donde más operadores se hunden por no conocer sus derechos:</p>
          <ul>
            <li><strong>Derecho a no declarar.</strong> Puedes reservarte tu declaración hasta contar con abogado. Guardar silencio NO es admisión de culpa y no puede usarse en tu contra. La declaración sin defensor es la fuente número uno de problemas evitables.</li>
            <li><strong>Derecho a un defensor.</strong> Desde el primer acto tienes derecho a un abogado: el de tu empresa, uno particular, o un defensor público. Exígelo antes de firmar o declarar cualquier cosa. La frase correcta: <em>"Voy a declarar con mucho gusto en cuanto esté presente mi defensor."</em></li>
            <li><strong>Derecho a conocer de qué se te acusa</strong> y a comunicarte: avisa a tu familia y a tu empresa dónde estás. No estás incomunicado.</li>
            <li><strong>La unidad y la carga:</strong> normalmente quedarán aseguradas (corralón/depósito) mientras se hace el peritaje. Su liberación es un trámite posterior que gestiona el abogado con la aseguradora; no firmes salidas "exprés" informales.</li>
            <li><strong>Exámenes:</strong> es normal que te practiquen examen médico y de alcohol/drogas. Coopera: si estás limpio, ese examen es tu mejor evidencia inmediata.</li>
            <li><strong>En accidentes de tránsito, la ley general contempla salidas alternas</strong> (acuerdos reparatorios cubiertos por el seguro) para delitos culposos; con defensa adecuada, la gran mayoría de percances sin agravantes se resuelven sin prisión. Con alcohol, fuga u omisión de auxilio, el panorama cambia por completo: <strong>nunca abandones la escena.</strong></li>
          </ul>
          <p class="tip">Resumen para memorizar: <strong>no declaro sin abogado, no firmo sin leer, no me retiro de la escena, sí coopero con el examen médico.</strong> Cuatro decisiones que definen tu futuro más que el accidente mismo.</p>
        `
      }
    ],
    quiz: [
      { q: "¿Cuál es el orden correcto de prioridades tras un accidente?", options: ["Evidencia → empresa → 911", "Tu integridad → asegurar la zona → 911 → heridos → evidencia", "911 → mover unidades → fotos", "Hablar con el tercero → aseguradora → 911"], correct: 1 },
      { q: "Los dispositivos de advertencia (triángulos) en carretera federal se colocan:", options: ["A 10 pasos de la unidad", "Solo si hay niebla", "A distancia suficiente para que el tráfico reaccione: cientos de metros, más en curvas o de noche", "Detrás de la cabina"], correct: 2 },
      { q: "¿Cuándo es válido mover a un lesionado?", options: ["Cuando estorba el tráfico", "Solo ante riesgo inminente como fuego o explosión", "Cuando el tercero lo pide", "Siempre, para llevarlo a la sombra"], correct: 1 },
      { q: "Frente al oficial y al tercero, lo correcto es describir:", options: ["Tus conclusiones sobre quién tuvo la culpa", "Hechos objetivos, sin admitir culpa: la responsabilidad la determina el perito", "Nada en absoluto, ni tu nombre", "Solo lo que diga tu empresa por teléfono"], correct: 1 },
      { q: "Te presentan un documento para firmar en la escena y no puedes leerlo completo:", options: ["Firmas para agilizar", "No firmas; esperas al ajustador o abogado, o firmas solo de recibido sin aceptar contenido", "Firmas con otro nombre", "Lo rompes"], correct: 1 },
      { q: "¿Por qué NO debes mover las unidades si hay lesionados o daños mayores?", options: ["Porque se daña la caja de velocidades", "Porque la posición final es evidencia para el peritaje", "Porque lo prohíbe la aseguradora del tercero", "Sí debes moverlas siempre"], correct: 1 },
      { q: "¿Qué evidencia conviene levantar de los testigos?", options: ["Solo su apodo", "Nombre, teléfono y dos líneas de lo que dicen, antes de que se retiren", "Nada: el perito los localiza después", "Su credencial de elector en original"], correct: 1 },
      { q: "Ante el Ministerio Público, guardar silencio hasta tener abogado:", options: ["Es admisión tácita de culpa", "Es tu derecho y no puede usarse en tu contra", "Solo aplica para delitos graves", "Requiere permiso de la empresa"], correct: 1 },
      { q: "El examen médico y de alcohol/drogas tras el accidente:", options: ["Debes rechazarlo siempre", "Conviene cooperar: si estás limpio, es tu mejor evidencia inmediata", "Solo aplica a los del tercero", "Se hace únicamente con orden judicial"], correct: 1 },
      { q: "¿Cuál de estas conductas cambia por completo tu panorama legal, para mal?", options: ["Llamar al 911", "Abandonar la escena del accidente", "Esperar al ajustador", "Tomar fotografías"], correct: 1 }
    ]
  }
,

  {
    id: "nom-068",
    title: "NOM-068: inspección diaria de tu unidad",
    badge: "068",
    color: "#1D4ED8",
    desc: "La revisión físico-mecánica que evita multas, varadas y accidentes: qué inspeccionar antes de cada viaje, cómo documentarlo y qué te revisan en los operativos.",
    duracion: "≈ 45 min",
    lessons: [
      {
        id: "n68-1",
        title: "Qué exige la norma y por qué te conviene",
        html: `
          <p>La <strong>NOM-068-SCT-2-2014</strong> establece las <strong>condiciones físico-mecánicas</strong> que debe cumplir todo vehículo de autotransporte federal para circular. Su instrumento central es la <strong>inspección diaria de la unidad antes de iniciar el viaje</strong>.</p>
          <ul>
            <li><strong>Obliga a ambos:</strong> el permisionario debe mantener la unidad en condiciones y verificar la inspección; el conductor debe realizarla y reportar fallas. Si operas una unidad con falla conocida y no reportada, compartes responsabilidad.</li>
            <li><strong>Tu interés directo:</strong> una falla de frenos, luces o llantas no le pasa a la empresa: te pasa a ti a 90 km/h con 40 toneladas atrás. La inspección diaria es la herramienta de seguridad más rentable que existe: 15 minutos que evitan la varada de un día o el accidente de una vida.</li>
            <li><strong>En operativos e inspecciones</strong> (SICT/Guardia Nacional) revisan físicamente los puntos de la norma. Una unidad reprobada puede ser retirada de circulación en el momento, con la carga a bordo.</li>
          </ul>
          <p class="tip">Mentalidad profesional: la inspección no es "un formato que llenar para la empresa"; es TU revisión de la máquina de la que depende tu vida y tu sustento.</p>
        `
      },
      {
        id: "n68-2",
        title: "El recorrido de inspección: los puntos críticos",
        html: `
          <p>Un recorrido eficiente sigue siempre la misma ruta alrededor de la unidad para no saltarte nada. Los grupos críticos:</p>
          <ol>
            <li><strong>Frenos (el número uno):</strong> fugas de aire audibles, presión del sistema (que los tanques carguen y mantengan), carrera de las matracas/ajustadores, mangueras sin grietas ni rozaduras, y prueba de frenado a baja velocidad antes de salir. En el remolque: conexión firme de las mangueras de servicio y emergencia.</li>
            <li><strong>Llantas y ruedas:</strong> profundidad de dibujo (nunca por debajo del mínimo legal; direccionales con más exigencia), presión correcta, sin cortes, abombamientos ni desgaste irregular; birlos y tuercas completos y sin marcas de giro (las líneas de óxido delatan tuercas flojas).</li>
            <li><strong>Luces y eléctrico:</strong> todas las lámparas (frenado, direccionales, cuartos, reversa, torreta si aplica), reflejantes limpios y completos, conexión eléctrica al remolque.</li>
            <li><strong>Acoplamiento (quinta rueda):</strong> perno rey bien asegurado, mordaza cerrada y con seguro, sin holgura excesiva; patines del remolque arriba y asegurados.</li>
            <li><strong>Dirección y suspensión:</strong> holgura del volante dentro de lo normal, muelles sin hojas rotas, bolsas de aire sin fugas, amortiguadores sin escurrimientos.</li>
            <li><strong>Fluidos y motor:</strong> niveles (aceite, refrigerante, dirección), fugas visibles bajo la unidad, bandas y mangueras.</li>
            <li><strong>Cabina y seguridad:</strong> parabrisas sin daños que obstruyan la vista, limpiadores, espejos completos y bien dirigidos, cinturón, extintor cargado y a la mano, triángulos/señalamientos, botiquín.</li>
          </ol>
          <p class="tip">Hazlo SIEMPRE en el mismo orden (por ejemplo: cabina → frente → lado derecho hacia atrás → remolque → lado izquierdo de regreso). La rutina fija es lo que hace que un día con prisa no te saltes los frenos.</p>
        `
      },
      {
        id: "n68-3",
        title: "Documentar la inspección y reportar fallas",
        html: `
          <p>La inspección que no se documenta, legalmente no existe. Cómo hacerlo bien:</p>
          <ul>
            <li><strong>Formato de inspección diaria:</strong> usa el formato de tu empresa (físico o app) marcando cada punto revisado, con fecha, hora, kilometraje y tu firma. Si tu empresa no tiene formato, propón uno: también la protege a ella.</li>
            <li><strong>Reporte de fallas por escrito:</strong> toda falla detectada se reporta ANTES de salir, por un medio que deje constancia (mensaje, formato firmado de recibido). La frase clave del profesional: <em>"unidad con falla reportada, en espera de indicación por escrito".</em></li>
            <li><strong>Si te ordenan salir con una falla de seguridad</strong> (frenos, llantas lisas, luces principales): negarte está justificado — la NOM y la LFT te respaldan, y en caso de accidente esa orden escrita reparte la responsabilidad hacia quien la dio. Sin evidencia de que reportaste, la versión oficial será "el operador nunca avisó".</li>
            <li><strong>Fotos con fecha:</strong> ante una falla relevante (llanta dañada, fuga), una foto enviada a tu empresa vale más que diez llamadas.</li>
          </ul>
          <p class="tip">Tu archivo personal (fotos de formatos y reportes en tu teléfono) es tu seguro laboral y penal. Cuesta cero y un día puede valer tu libertad o tu liquidación.</p>
        `
      },
      {
        id: "n68-4",
        title: "Verificaciones periódicas y qué revisan los operativos",
        html: `
          <p>Además de tu inspección diaria, la unidad debe pasar su <strong>verificación de condiciones físico-mecánicas periódica</strong> en unidades autorizadas, y portar la constancia/holograma vigente. También aplican la verificación de emisiones y, según la ruta, básculas de peso y dimensiones (NOM-012).</p>
          <p><strong>En un operativo típico revisan:</strong> constancia físico-mecánica vigente, frenos (pueden probar fugas y ajuste), llantas, luces, acoplamiento, y que la configuración del vehículo coincida con el permiso. Todo eso es exactamente tu recorrido de la lección 2 — por eso quien inspecciona a diario pasa los operativos sin sustos.</p>
          <p><strong>Si la unidad reprueba en el operativo:</strong> mantén la calma, documenta qué punto señalaron (foto del acta), avisa a tu empresa de inmediato y no intentes "arreglos" informales en el punto de revisión: cualquier ofrecimiento indebido convierte una infracción administrativa en un problema penal.</p>
          <p><strong>Vencimientos que tú debes traer en la cabeza</strong> (no dependas de que la empresa los recuerde): tu licencia federal, tu examen psicofísico integral, la verificación físico-mecánica de la unidad y la póliza de seguro. Un profesional conoce sus fechas como conoce su ruta.</p>
          <p class="tip">Regla final del curso: <strong>unidad que no revisaste, unidad que no conoces.</strong> Y a lo desconocido no se le confía la vida.</p>
        `
      }
    ],
    quiz: [
      { q: "¿Cuál es el instrumento central de la NOM-068 en la operación diaria?", options: ["El pago de casetas", "La inspección de la unidad antes de iniciar el viaje", "El lavado semanal de la unidad", "El registro de combustible"], correct: 1 },
      { q: "¿Cuál es el punto MÁS crítico del recorrido de inspección?", options: ["El estéreo", "Los frenos y sus conexiones al remolque", "La pintura de la cabina", "Las loderas"], correct: 1 },
      { q: "Las líneas de óxido que salen de las tuercas de una rueda suelen delatar:", options: ["Llanta nueva", "Tuercas flojas o que han girado", "Exceso de presión", "Buena alineación"], correct: 1 },
      { q: "En la quinta rueda, antes de salir debes confirmar:", options: ["Solo que el remolque esté enganchado 'a ojo'", "Perno rey asegurado, mordaza cerrada con seguro y sin holgura excesiva", "Que los patines vayan abajo", "Nada, eso es del mecánico"], correct: 1 },
      { q: "Una inspección que no se documenta:", options: ["Vale igual", "Legalmente no existe", "Solo importa en empresas grandes", "La puede firmar cualquiera después"], correct: 1 },
      { q: "Detectas una falla de frenos y te ordenan salir 'como sea'. Lo profesional es:", options: ["Salir despacio", "Negarte, con el reporte de la falla por escrito", "Salir y frenar con motor", "Cambiar de unidad sin avisar"], correct: 1 },
      { q: "¿Por qué conviene hacer el recorrido siempre en el mismo orden?", options: ["Por superstición", "Para que la rutina evite saltarte puntos los días con prisa", "Porque lo exige la Guardia Nacional", "Para terminar más rápido"], correct: 1 },
      { q: "En un operativo, la unidad reprueba un punto físico-mecánico. NO debes:", options: ["Fotografiar el acta", "Avisar a tu empresa", "Intentar un 'arreglo' informal con el inspector", "Documentar qué punto señalaron"], correct: 2 },
      { q: "Además de la inspección diaria, la unidad debe contar con:", options: ["Verificación físico-mecánica periódica vigente", "Un dictamen notarial", "Permiso de la aseguradora para circular", "Carta de la agencia"], correct: 0 },
      { q: "¿Qué vencimientos debe traer el operador 'en la cabeza'?", options: ["Solo el de la tarjeta de circulación", "Licencia, psicofísico, verificación de la unidad y seguro", "Ninguno, son responsabilidad de la empresa", "Solo los de la unidad"], correct: 1 }
    ]
  },

  {
    id: "derechos-laborales",
    title: "Derechos laborales del operador",
    badge: "LFT",
    color: "#6D28D9",
    desc: "Lo que la ley te garantiza y casi nadie te dice: IMSS, salario real, descuentos ilegales, jornada, y cómo documentar tu relación de trabajo sin pelearte con nadie. Escrito por abogados laborales.",
    duracion: "≈ 50 min",
    lessons: [
      {
        id: "dl-1",
        title: "Tu relación de trabajo existe aunque no haya contrato",
        html: `
          <p>Empecemos por el principio que cambia todo: en México, <strong>la relación de trabajo se demuestra con los hechos, no con el papel</strong>. Si prestas un servicio personal subordinado (te dicen qué ruta, en qué unidad, con qué horarios) a cambio de un pago, ERES trabajador con todos los derechos de la Ley Federal del Trabajo — aunque te paguen "por viaje", aunque no hayas firmado nada, aunque te digan que eres "socio" o te hagan facturar.</p>
          <ul>
            <li><strong>La falta de contrato escrito perjudica al patrón, no a ti:</strong> la ley presume ciertas condiciones a tu favor cuando no hay contrato.</li>
            <li><strong>El esquema "por fuera" más común del gremio</strong> — pagarte por viaje sin IMSS, o con IMSS registrado con salario mínimo mientras ganas mucho más — es ilegal y le sale carísimo a la empresa en un juicio, porque las prestaciones y la liquidación se calculan sobre tu <em>salario real</em>, incluyendo lo variable.</li>
            <li><strong>Los choferes tienen capítulo propio en la LFT</strong> (trabajo de autotransportes): tu salario puede ser por día, por viaje o por kilómetro, pero nunca por debajo del mínimo, y los viáticos no sustituyen al salario.</li>
          </ul>
          <p class="tip">No necesitas pelear hoy: necesitas SABER. Conocer tu situación real te permite decidir con calma — negociar, exigir o cambiarte a una empresa seria con datos en la mano.</p>
        `
      },
      {
        id: "dl-2",
        title: "IMSS, prestaciones y el salario con el que deben registrarte",
        html: `
          <p>Checklist de lo que te corresponde por ley, sin excepción por ser "de confianza" o "por viaje":</p>
          <ul>
            <li><strong>IMSS desde el primer día</strong>, registrado con tu <strong>salario real integrado</strong> (incluyendo el promedio de lo variable: viajes, kilómetros, comisiones). Registrarte con menos afecta tus incapacidades, tu crédito Infonavit y tu pensión futura.</li>
            <li><strong>Aguinaldo</strong> (mínimo 15 días de salario, proporcional), <strong>vacaciones</strong> con prima del 25%, <strong>prima dominical</strong> si trabajas domingos, <strong>utilidades (PTU)</strong> si la empresa genera.</li>
            <li><strong>Infonavit y Afore:</strong> aportaciones sobre tu salario real. Revisa tu semanas cotizadas y tu salario registrado en la app del IMSS — es gratis y tardas 5 minutos; ahí descubres si te registraron con menos.</li>
            <li><strong>Incapacidades y riesgos de trabajo:</strong> un accidente en ruta ES riesgo de trabajo, incluso yendo o viniendo del trabajo en ciertos supuestos (accidente en trayecto). El IMSS cubre atención y subsidio; que la empresa te pida "no reportarlo" te deja desprotegido a ti.</li>
          </ul>
          <p><strong>Cómo verificar tu situación en 5 minutos:</strong> descarga la app <em>IMSS Digital</em> → Constancia de Semanas Cotizadas → revisa: ¿estás dado de alta?, ¿con qué salario?, ¿con qué patrón? Ese documento es la radiografía de tu realidad laboral.</p>
          <p class="tip">Dato que pocos saben: si cobras "por fuera", cada año que pasa la empresa acumula un pasivo laboral enorme contigo. Tu antigüedad y tu salario real no se borran por como te paguen.</p>
        `
      },
      {
        id: "dl-3",
        title: "Descuentos ilegales: mermas, diésel, daños y multas",
        html: `
          <p>La práctica más abusiva del gremio: descontarte de tu pago las mermas de carga, faltantes de diésel, daños a la unidad o multas. La regla legal es clara: <strong>los descuentos al salario están prohibidos salvo las excepciones que la propia LFT enumera</strong> (cuotas IMSS, impuestos, pensión alimenticia ordenada por juez, Infonavit/Fonacot, y pocos más, con topes).</p>
          <ul>
            <li><strong>Mermas y faltantes:</strong> el riesgo de la mercancía es del negocio, no del trabajador. Solo podrían cobrarte un daño si se acredita legalmente tu responsabilidad directa (dolo o negligencia probada), no por descuento automático de raya, y aun así con límites estrictos.</li>
            <li><strong>Daños a la unidad:</strong> misma regla. "Chocaste, te lo descuento" sin procedimiento es ilegal.</li>
            <li><strong>Multas de tránsito:</strong> las de la unidad (verificación, condiciones físico-mecánicas, permisos) son del permisionario. Las personalísimas por tu conducción son otra historia — pero tampoco pueden simplemente descontártelas de raya sin tu consentimiento expreso y por escrito.</li>
            <li><strong>Depósitos "en garantía"</strong> que te retienen de tus primeras semanas: ilegales también.</li>
          </ul>
          <p><strong>Qué hacer sin pelear:</strong> nunca firmes recibos de raya que incluyan descuentos que no reconoces; si te obligan, escribe junto a tu firma "bajo protesta, no reconozco el descuento". Guarda fotos de cada recibo y de los mensajes donde te anuncian descuentos. Ese archivo, el día que decidas reclamar, vale cada peso descontado — y los descuentos ilegales se pueden reclamar hacia atrás.</p>
          <p class="tip">La empresa que descuenta mermas ilegalmente cuenta con que el operador no sabe o no guarda evidencia. Tú ya sabes, y guardar evidencia cuesta cero.</p>
        `
      },
      {
        id: "dl-4",
        title: "Jornada, renuncia, despido y cómo reclamar bien",
        html: `
          <p><strong>Jornada:</strong> tu jornada laboral incluye TODO el tiempo a disposición del patrón: conducción, cargas, descargas, esperas en patios y aduanas. La NOM-087 limita la conducción; la LFT limita la jornada y ordena pagar el excedente como tiempo extra (con reglas de pago doble y triple). Las esperas de 10 horas en un patio no son "tiempo muerto gratis": son jornada.</p>
          <p><strong>Si te despiden:</strong> tienes derecho a liquidación (3 meses de salario integrado + 20 días por año en su caso + prima de antigüedad + proporcionales) salvo causa justificada probada por el patrón. <strong>No firmes tu renuncia como condición para que te paguen</strong> — la "renuncia" firmada convierte tu despido en abandono voluntario y mata tu liquidación. Tampoco firmes hojas en blanco al entrar a trabajar (práctica tristemente común: luego aparecen convertidas en renuncia).</p>
          <p><strong>Si renuncias tú:</strong> te corresponden partes proporcionales (aguinaldo, vacaciones, prima) y prima de antigüedad si tienes 15+ años. Renunciar no es "salir con las manos vacías".</p>
          <p><strong>Plazos que debes conocer:</strong> la acción por despido injustificado tiene un plazo corto (2 meses desde el despido) — si te despiden, busca asesoría INMEDIATAMENTE, no "cuando haya tiempo". Otros reclamos (prestaciones, descuentos) tienen plazos más largos (generalmente 1 año).</p>
          <p><strong>Dónde reclamar hoy:</strong> el sistema actual exige primero la <strong>conciliación prejudicial</strong> (Centro de Conciliación) antes del juicio ante los tribunales laborales. Muchos asuntos se resuelven ahí en semanas, con convenio pagado en el momento.</p>
          <p class="tip">El mejor pleito es el que se gana sin pelearse: operador que conoce sus derechos, documenta su relación y sus pagos, y consulta a tiempo, negocia desde una posición donde a la empresa le conviene más arreglarse que litigar.</p>
        `
      }
    ],
    quiz: [
      { q: "La relación de trabajo en México se demuestra principalmente con:", options: ["El contrato firmado únicamente", "Los hechos: servicio personal subordinado a cambio de un pago", "La credencial de la empresa", "El registro ante la SICT"], correct: 1 },
      { q: "Si no hay contrato escrito, la ley:", options: ["Presume condiciones a favor del trabajador; la omisión perjudica al patrón", "Anula la relación laboral", "Presume que eres socio", "Obliga a facturar"], correct: 0 },
      { q: "El IMSS debe registrarte con:", options: ["El salario mínimo siempre", "Tu salario real integrado, incluyendo el promedio de lo variable", "Solo la parte fija", "Lo que la empresa decida"], correct: 1 },
      { q: "Descontarte de la raya las mermas de carga automáticamente es:", options: ["Legal si lo avisan", "Ilegal: los descuentos al salario están prohibidos salvo excepciones de ley", "Legal hasta el 30%", "Legal si eres de confianza"], correct: 1 },
      { q: "Te piden firmar tu renuncia 'para poder pagarte'. Lo correcto es:", options: ["Firmar para cobrar rápido", "No firmar: la renuncia mata tu liquidación; buscar asesoría de inmediato", "Firmar con otra fecha", "Firmar y luego demandar igual"], correct: 1 },
      { q: "Las esperas de horas en patios y aduanas:", options: ["No cuentan para nada", "Son tiempo a disposición del patrón: forman parte de la jornada", "Solo cuentan si hay clima malo", "Se pagan con comida"], correct: 1 },
      { q: "El plazo para accionar por despido injustificado es:", options: ["5 años", "Corto: 2 meses desde el despido", "1 semana", "No hay plazo"], correct: 1 },
      { q: "¿Dónde inicia hoy un reclamo laboral típico?", options: ["Directo en juicio penal", "En la conciliación prejudicial ante el Centro de Conciliación", "En la SICT", "Con la aseguradora"], correct: 1 },
      { q: "Un accidente en ruta durante tu trabajo es, para efectos del IMSS:", options: ["Un asunto personal", "Un riesgo de trabajo que debe reportarse", "Culpa del operador siempre", "Algo que conviene no reportar"], correct: 1 },
      { q: "¿Cuál es la mejor 'herramienta legal' cotidiana del operador?", options: ["Discutir con el patrón", "Guardar evidencia: recibos, mensajes, fotos, y consultar a tiempo", "No firmar nunca nada, ni recibos legítimos", "Cambiar de empresa cada mes"], correct: 1 }
    ]
  },

  {
    id: "ahorro-diesel",
    title: "Manejo técnico-económico: ahorra diésel",
    badge: "ECO",
    color: "#0F766E",
    desc: "El diésel es el mayor costo del flete y el operador controla hasta un 30% de la diferencia. Técnicas de conducción eficiente que te hacen más valioso para cualquier flota — y más rentable si eres hombre-camión.",
    duracion: "≈ 40 min",
    lessons: [
      {
        id: "ad-1",
        title: "Por qué el operador ES el factor de consumo",
        html: `
          <p>Entre dos unidades idénticas con la misma carga y la misma ruta, la diferencia de consumo entre un operador promedio y uno técnico puede llegar a <strong>20-30%</strong>. En una unidad que recorre 12,000 km al mes, eso son decenas de miles de pesos al año — por eso las flotas serias miden el rendimiento por operador y <strong>pagan bonos de combustible</strong>.</p>
          <ul>
            <li><strong>Para ti como empleado:</strong> tu rendimiento km/l es un argumento de contratación y de bono. "Manejo un promedio de X km/l en T3S2 cargado" es una frase que un reclutador de flota entiende inmediatamente.</li>
            <li><strong>Para ti como hombre-camión:</strong> el diésel es tu costo #1; cada punto porcentual de ahorro va directo a tu bolsillo.</li>
            <li><strong>Los tres enemigos del rendimiento:</strong> las aceleradas/frenadas innecesarias (energía tirada), las RPM fuera del rango económico, y el ralentí (motor encendido sin moverse).</li>
          </ul>
          <p class="tip">Este curso no te pide manejar más lento ni llegar más tarde: te pide manejar con la cabeza. El manejo técnico suele ser incluso más rápido puerta a puerta, porque es más fluido y castiga menos a la unidad.</p>
        `
      },
      {
        id: "ad-2",
        title: "Las técnicas: RPM, inercia y anticipación",
        html: `
          <p>Los principios del manejo técnico, aplicables a cualquier tracto:</p>
          <ul>
            <li><strong>Opera en la zona económica del motor:</strong> cada motor tiene su rango de RPM de máxima eficiencia (la "zona verde" del tacómetro, típicamente en RPM bajas-medias donde el torque es máximo). Cambia de velocidad temprano para mantenerte ahí; revolucionar de más quema diésel sin ganar velocidad real.</li>
            <li><strong>La anticipación es la técnica reina:</strong> lee el camino 500 metros adelante. Si el semáforo está en rojo o el tráfico se detiene, suelta el acelerador desde lejos y llega rodando en lugar de llegar acelerando y frenar. Cada frenada convierte en calor el diésel que ya pagaste.</li>
            <li><strong>Usa la inercia a tu favor:</strong> aprovecha las bajadas para recuperar velocidad sin acelerador (con la marcha adecuada y freno de motor listo — inercia no significa bajar en neutral, que es peligroso y está prohibido). Ataca las subidas con impulso previo en lugar de a fondo desde abajo.</li>
            <li><strong>Velocidad de crucero constante y moderada:</strong> arriba de cierta velocidad, la resistencia del aire crece exponencialmente; los últimos 10 km/h de velocidad son los más caros del viaje. Constante y planeado gana a rápido y frenado.</li>
            <li><strong>Mata el ralentí:</strong> esperas largas con motor encendido para el clima son de los desperdicios más grandes de una flota. Donde sea seguro y razonable, motor apagado.</li>
          </ul>
          <p class="tip">Métrica personal: anota kilómetros y litros de cada carga de diésel durante un mes. Tu km/l real, medido por ti, es la línea base que vas a mejorar — y el número que vas a presumir en tu perfil.</p>
        `
      },
      {
        id: "ad-3",
        title: "La unidad también ahorra: presión, alineación y aerodinámica",
        html: `
          <p>El mejor operador no compensa una unidad descuidada. Lo que debes vigilar (y reportar) porque impacta directo al consumo:</p>
          <ul>
            <li><strong>Presión de llantas:</strong> la causa mecánica #1 de sobreconsumo. Llantas bajas aumentan la resistencia al rodado y además se destruyen antes. Revisa presión en frío como parte de tu inspección NOM-068 — este curso y aquel son el mismo hábito.</li>
            <li><strong>Alineación y arrastre del remolque:</strong> una caja "cangrejeando" (desalineada) arrastra la unidad entera. Señales: desgaste disparejo de llantas del remolque, jaloneo constante.</li>
            <li><strong>Aerodinámica:</strong> deflectores en su posición correcta según la altura de la caja, lonas bien tensadas (una lona floja aletea y frena), y en plataformas, carga acomodada para presentar el menor frente posible al aire.</li>
            <li><strong>Filtros y mantenimiento:</strong> filtro de aire saturado = motor ahogado = más diésel. Reporta los servicios vencidos; el sobreconsumo también es síntoma de fallas (inyectores, fugas) que detectas tú antes que el taller.</li>
            <li><strong>El peso honesto:</strong> cada tonelada de más cuesta diésel y multas (NOM-012). El sobrepeso "que nadie nota" lo nota tu tanque siempre.</li>
          </ul>
          <p class="tip">Cuando reportes una condición que gasta diésel (llantas bajas, deflector caído), díselo a la flota en su idioma: "esto nos está costando rendimiento". Un operador que habla de costos es un operador que ascienden.</p>
        `
      },
      {
        id: "ad-4",
        title: "Convierte tu rendimiento en dinero y en currículum",
        html: `
          <p>Cierre del curso: cómo capitalizar lo aprendido.</p>
          <ul>
            <li><strong>Mide y registra:</strong> lleva tu bitácora personal de rendimiento (fecha, ruta, carga aproximada, litros, kilómetros, km/l). Tres meses de datos son tu evidencia dura.</li>
            <li><strong>Negocia bonos con datos:</strong> si tu flota no tiene bono de combustible, propónlo: "mi promedio es X, el de la flota es Y; propongo repartir el ahorro". A la empresa le conviene matemáticamente y tú institucionalizas tu ingreso extra.</li>
            <li><strong>En tu perfil profesional</strong> (aquí en OperadorPro) registra tu rendimiento promedio por configuración. Junto con tus certificados, arma el expediente del operador que toda logística quiere: documentado, dentro de norma y rentable.</li>
            <li><strong>Si eres hombre-camión:</strong> tu km/l real alimenta tu cotización por kilómetro. Cotizar sin conocer tu costo real por km (diésel + casetas + desgaste + tu sueldo) es regalar viajes; el manejo técnico baja ese costo y ensancha tu margen en cada flete.</li>
            <li><strong>Seguridad como bono extra:</strong> el manejo anticipado no solo ahorra diésel: reduce drásticamente el riesgo de alcance (el accidente más común del tracto). Menos sustos, menos deducibles, mejor historial — y el historial también es currículum.</li>
          </ul>
          <p class="tip">La ecuación final del curso: <strong>anticipación = diésel + seguridad + prestigio.</strong> Tres pagos por el mismo hábito.</p>
        `
      }
    ],
    quiz: [
      { q: "¿Cuánta diferencia de consumo puede haber entre un operador promedio y uno técnico?", options: ["Prácticamente ninguna", "Hasta 20-30%", "Solo 1%", "Solo importa la unidad"], correct: 1 },
      { q: "La 'técnica reina' del manejo económico es:", options: ["Bajar en neutral", "La anticipación: leer el camino cientos de metros adelante", "Acelerar fuerte y frenar fuerte", "Ir siempre al límite de velocidad"], correct: 1 },
      { q: "Cada frenada innecesaria significa:", options: ["Nada relevante", "Convertir en calor el diésel que ya pagaste", "Ahorro de llantas", "Mejor tiempo de llegada"], correct: 1 },
      { q: "Aprovechar la inercia en bajadas significa:", options: ["Bajar en neutral para no gastar", "Rodar sin acelerador con la marcha adecuada y freno de motor listo", "Apagar el motor en la pendiente", "Rebasar en la bajada"], correct: 1 },
      { q: "¿Por qué los últimos 10 km/h de velocidad son 'los más caros'?", options: ["Por las multas", "Porque la resistencia del aire crece exponencialmente con la velocidad", "Porque se paga más caseta", "No es cierto que cuesten más"], correct: 1 },
      { q: "La causa mecánica #1 de sobreconsumo es:", options: ["El color de la unidad", "La presión baja de llantas", "El clima", "El tipo de música"], correct: 1 },
      { q: "El ralentí prolongado (motor encendido sin moverse):", options: ["No consume", "Es de los mayores desperdicios de combustible de una flota", "Es obligatorio por norma", "Ahorra arranques"], correct: 1 },
      { q: "¿Cómo conviertes tu buen rendimiento en dinero como empleado?", options: ["Guardándolo en secreto", "Midiéndolo y negociando bonos de combustible con datos", "Cargando menos diésel", "Manejando más horas"], correct: 1 },
      { q: "Para un hombre-camión, conocer su costo real por kilómetro sirve para:", options: ["Nada práctico", "Cotizar fletes con margen en lugar de regalar viajes", "Pagar menos impuestos automáticamente", "Evitar las básculas"], correct: 1 },
      { q: "El manejo anticipado, además de diésel, reduce sobre todo el riesgo de:", options: ["Accidente por alcance", "Multas de estacionamiento", "Robo de combustible", "Desgaste del estéreo"], correct: 0 }
    ]
  }
];

const PASSING_SCORE = 8; // de 10 reactivos

if (typeof module !== "undefined") { module.exports = { COURSES, PASSING_SCORE }; }
