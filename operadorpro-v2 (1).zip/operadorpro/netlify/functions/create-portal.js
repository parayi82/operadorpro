// ============================================================
// create-portal.js — Abre el Stripe Billing Portal para que el
// usuario administre su suscripción: cambiar de plan, actualizar
// tarjeta o cancelar. Requiere activar el portal en Stripe:
// Settings > Billing > Customer portal (permitir cambio entre
// los dos precios de OperadorPro).
// ============================================================

const Stripe = require("stripe");
const { createClient } = require("@supabase/supabase-js");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Método no permitido" }) };
  }

  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const admin = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

    const token = (event.headers.authorization || "").replace("Bearer ", "");
    const { data: userData, error: userErr } = await admin.auth.getUser(token);
    if (userErr || !userData?.user) {
      return { statusCode: 401, body: JSON.stringify({ error: "Sesión no válida" }) };
    }

    const { data: profile } = await admin
      .from("profiles").select("stripe_customer_id")
      .eq("id", userData.user.id).single();

    if (!profile?.stripe_customer_id) {
      return { statusCode: 400, body: JSON.stringify({ error: "Aún no tienes una suscripción que administrar" }) };
    }

    const session = await stripe.billingPortal.sessions.create({
      customer: profile.stripe_customer_id,
      return_url: `${process.env.SITE_URL}/app.html#/perfil`
    });

    return { statusCode: 200, body: JSON.stringify({ url: session.url }) };
  } catch (e) {
    console.error("create-portal error:", e);
    return { statusCode: 500, body: JSON.stringify({ error: "No se pudo abrir el portal de suscripción" }) };
  }
};
